
Backend (NestJS) - Docker-only v2.1
Run with docker compose: `docker compose up --build`
Seed user: admin@teddy.com / password
Swagger: /docs
Health: /healthz
Metrics: /metrics
