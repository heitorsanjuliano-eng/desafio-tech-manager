Frontend (React + Vite) - Docker-only v2.1
Run: docker compose up --build
