
# teddy-tech-manager v2.1 (Docker-only)

Versão Docker-only: Dockerfiles usam `npm install` para permitir builds em máquinas que não têm Node/npm instalados.
Monorepo com frontend (React + Vite + TS) e backend (NestJS + TypeORM + Postgres).
Rodar com Docker Compose: `docker compose up --build`

Seed user: admin@teddy.com / password
